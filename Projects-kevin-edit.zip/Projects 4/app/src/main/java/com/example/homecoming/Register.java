package com.example.homecoming;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Register extends AppCompatActivity {

    private Button btnCustomer;
    private Button btnAgentOwner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        init();
        setClickListener();
    }

    //If needed, use it. Otherwise, delete.
    private void init() {
        btnCustomer = findViewById(R.id.btnCustomer);
        btnAgentOwner = findViewById(R.id.btnAgentOwner);
    }

    private void setClickListener() {
        btnCustomer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Register.this, Customer.class);
                startActivity(intent);
            }
        });
        btnAgentOwner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Register.this, Owner_Agent.class);
                startActivity(intent);
            }
        });
    }

}
