package com.example.homecoming;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

//TODO FOR TESTING, DELETE WHEN DONE
import java.util.ArrayList;
import java.util.List;

public class GraphTest extends AppCompatActivity {

    //TODO Add firebase vars here???
    private final FirebaseDatabase db = FirebaseDatabase.getInstance();
    private GenericTypeIndicator<List<String>> t = new GenericTypeIndicator<List<String>>() {};
    private DatabaseReference dbRef;
    private Button btnReload;
    private GraphView graph;
    private TextView txtTemperature;
    private TextView txtHumidity;
    private TextView txtTime;
    private LineGraphSeries<DataPoint> seriesTemperature;
    private LineGraphSeries<DataPoint> seriesHumidity;
    private DataPoint currentTemperature;
    private DataPoint currentHumidity;
    private String currentTimeTemp;
    private String currentTimeHumid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph_test);
        init();
    }

    private void init() {

        dbRef = db.getReference().child("sensorResults");

        graph = findViewById(R.id.graph);
        txtTemperature = findViewById(R.id.txtTemperature);
        txtHumidity = findViewById(R.id.txtHumidity);
        graph.setTitle("Temperature/Humidity History");

        seriesTemperature = new LineGraphSeries<>(new DataPoint[0]);
        seriesHumidity = new LineGraphSeries<>(new DataPoint[0]);
        graph.setTitleColor(Color.WHITE);
        graph.getGridLabelRenderer().setHorizontalLabelsVisible(false);
        graph.getGridLabelRenderer().setVerticalLabelsVisible(false);
        graph.getGridLabelRenderer().setHumanRounding(false);

        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                int i = 0;
                int prevHumid = -1;
                double prevTemp = -1;
                graph.getViewport().setMaxX(dataSnapshot.getChildrenCount()-1);
                DataPoint[] dataPointsTemp = new DataPoint[(int)dataSnapshot.getChildrenCount()];
                DataPoint[] dataPointsHumid = new DataPoint[(int)dataSnapshot.getChildrenCount()];
                graph.removeAllSeries();

                for (DataSnapshot data: dataSnapshot.getChildren()) {
                    SensorResult result = data.getValue(SensorResult.class);
                    if (result.getTemperature() == -1)
                        dataPointsTemp[i] = new DataPoint(i, prevTemp);
                    else {
                        dataPointsTemp[i] = new DataPoint(i, result.getTemperature());
                        prevTemp = result.getTemperature();
                    }
                    if (result.getHumidity() == -1)
                        dataPointsHumid[i] = new DataPoint(i, prevHumid);
                    else {
                        dataPointsHumid[i] = new DataPoint(i, result.getHumidity());
                        prevHumid = result.getHumidity();
                    }
                    System.out.println("Temp: "+dataPointsTemp[i].toString()+", Humid: "+dataPointsHumid[i].toString());

                    if (result.getTemperature() != -1)
                        currentTimeTemp = result.getTime();
                    if (result.getHumidity() != -1)
                        currentTimeHumid = result.getTime();
                    i++;
                }

                seriesTemperature = new LineGraphSeries<>(dataPointsTemp);
                seriesHumidity = new LineGraphSeries<>(dataPointsHumid);
                seriesTemperature.setColor(Color.argb(150, 255, 127, 127));
                seriesHumidity.setColor(Color.argb(150, 127, 127, 255));
                graph.addSeries(seriesTemperature);
                graph.addSeries(seriesHumidity);
                graph.getViewport().setMinX(0);
                graph.getViewport().setMinY(0);
                graph.getViewport().setMaxY(150);

                currentTemperature = dataPointsTemp[(int)(dataSnapshot.getChildrenCount()-1)];
                currentHumidity = dataPointsHumid[(int)(dataSnapshot.getChildrenCount()-1)];
                System.out.println(currentTemperature+", "+currentHumidity);
                txtTemperature.setText("Last Checked Temperature (°F): "+currentTemperature.getY()+"°F as of "+currentTimeTemp);
                txtHumidity.setText("Last Checked Humidity: "+(int)(currentHumidity.getY())+"% as of "+currentTimeHumid);
                if (currentTemperature.getY() > 70 || currentTemperature.getY() < 55) {
                    seriesTemperature.setColor(Color.RED);
                    txtTemperature.setText(txtTemperature.getText()+" (WARNING!)");
                }
                if (currentHumidity.getY() > 50 || currentHumidity.getY() < 35) {
                    seriesHumidity.setColor(Color.BLUE);
                    txtHumidity.setText(txtHumidity.getText()+" (WARNING!)");
                }
                try {
                    Thread.sleep(1000);
                }
                catch(InterruptedException ex) {
                    Thread.currentThread().interrupt();
                }
                if (graph.getVisibility() == View.GONE)
                        graph.setVisibility(View.VISIBLE);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }
        });
    }

}

class SensorResult {

    private String time;
    private String tempHumid;

    public String getTime() {
        return time;
    }

    public String getTempHumid() {
        return tempHumid;
    }

    public String getTemperatureString() {
        if (tempHumid.indexOf("[No Data]") == 0)
            return "[No Data]";
        else
            return tempHumid.substring(0, (tempHumid.indexOf(' ')));
    }

    public String getHumidityString() {
        if (tempHumid.lastIndexOf("[No Data]") != 0 && tempHumid.lastIndexOf("[No Data]") != -1)
            return "[No Data]";
        else
            return tempHumid.substring(tempHumid.lastIndexOf(' ')+1);
    }

    public double getTemperature() {
        if (getTemperatureString().equals("[No Data]"))
            return -1;
        else
            return (Double.parseDouble(getTemperatureString()));
    }

    public int getHumidity() {
        if (getHumidityString().equals("[No Data]"))
            return -1;
        else
            return Integer.parseInt(getHumidityString());
    }

    @Override
    public String toString() {
        return "Temperature (F): "+getTemperatureString()+"\nHumidity: "+getHumidityString()+"\nTime: "+getTime();
    }

}
