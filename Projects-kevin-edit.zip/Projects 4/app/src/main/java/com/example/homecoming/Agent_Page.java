package com.example.homecoming;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

public class Agent_Page extends AppCompatActivity {

    private ListView list;
    private ArrayList<String> listItems;
    private ArrayAdapter<String> adapter;
    private EditText filter;
    private Button btnLogout;
    private String[] titles;
    private String[] description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_page);
        init();
    }

    private void init() {
        list = findViewById(R.id.listView);
        filter = findViewById(R.id.txtSearch);
        btnLogout = findViewById(R.id.btnLogout);
        titles = new String[]{"Dwell ATL"};
        description = new String[]{"171 Auburn Avenue NE, Atlanta, GA 30303"};

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //TODO dummy code, do stuff with this later
                Intent intent;

                switch(parent.getItemAtPosition(position).toString()) {

                    case "171 Auburn Avenue NE, Atlanta, GA 30303":
                        intent = new Intent(Agent_Page.this, GraphTest.class);
                        startActivity(intent);
                        break;
                    default:
                        System.err.println("Error: Address not in the database - "+list.getSelectedItem().toString());

                }
            }
        });
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logout();
            }
        });
        filter.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //Does nothing
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                initList();
                if(!(s.toString().equals(""))){
                    searchItem(s.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                //Does nothing
            }

        });

        initList();

    }

    //TODO do stuff with google and maybe security stuff as well
    private void logout() {
        finish();
    }

    private void searchItem(String textToSearch){

        for(String item: description){
            if(!(item.contains(textToSearch))){
                listItems.remove(item);
            }
        }

        adapter.notifyDataSetChanged();
    }

    //TODO this might need some work as well
    private void initList(){
        listItems = new ArrayList<>(Arrays.asList(description));
        adapter = new Agent_Page.MyAdapter(this, titles, listItems);
        list.setAdapter(adapter);
    }

    @Override
    public void onBackPressed() {
        //Overridden to do nothing to prevent people from logging off via back button
    }

    class MyAdapter extends ArrayAdapter<String> {

        Context context;
        String[] myTitles;

        MyAdapter(Context c, String[] titles, ArrayList<String> listItems) {
            super(c, R.layout.house_row, R.id.txtAddress, listItems);
            this.context = c;
            this.myTitles = titles;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater)   getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = layoutInflater.inflate(R.layout.house_row, parent, false);
            TextView myTitle = (TextView) row.findViewById(R.id.txtName);
            TextView myDescription = (TextView) row.findViewById(R.id.txtAddress);
            myTitle.setText(titles[position]);
            myDescription.setText(description[position]);
            return row;
        }
    }

}