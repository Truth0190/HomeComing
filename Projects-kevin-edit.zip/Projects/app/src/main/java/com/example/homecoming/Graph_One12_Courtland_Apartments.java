package com.example.homecoming;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Graph_One12_Courtland_Apartments extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph_one12_courtland_apartments);
    }
}
