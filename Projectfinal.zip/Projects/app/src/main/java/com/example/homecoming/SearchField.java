package com.example.homecoming;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Bundle;

import android.text.Editable;

import android.text.TextWatcher;

import android.view.View;
import android.widget.ArrayAdapter;

import android.widget.Button;
import android.widget.EditText;

import android.widget.ListView;

import com.example.homecoming.R;

import java.util.ArrayList;

import java.util.Arrays;

public class SearchField extends AppCompatActivity {


    String[] items;

    ArrayList<String> listItems;

    ArrayAdapter<String> adapter;

    ListView listView;

    EditText editText;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_search_field);

        listView=(ListView)findViewById(R.id.listview);

        editText=(EditText)findViewById(R.id.txtsearch);

        initList();

        editText.addTextChangedListener(new TextWatcher() {

            @Override

            public void beforeTextChanged(CharSequence s, int start, int count, int
                    after) {


            }


            @Override

            public void onTextChanged(CharSequence s, int start, int before, int
                    count) {

                if(s.toString().equals("")){

                    // reset listview

                    initList();

                }

                else{

                    // perform search

                    searchItem(s.toString());

                }
            }


            @Override

            public void afterTextChanged(Editable s) {



            }

        });

    }


    public void searchItem(String textToSearch){

        for(String item:items){

            if(!item.contains(textToSearch)){

                listItems.remove(item);

            }
        }

        adapter.notifyDataSetChanged();
    }

    public void initList(){

        items=new String[]{"30301","30302","30303","30304"};

        listItems=new ArrayList<>(Arrays.asList(items));

        adapter=new ArrayAdapter<String>(this,
                R.layout.activity_item_list, R.id.txtitem, listItems);

        listView.setAdapter(adapter);

    }

    public void buttonOnClick(View v) {
// do something when the button is clicked
        Button button=(Button) v;
        ((Button) v).setText("clicked");
    }


}
