package com.example.homecoming;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        init();
        setClickListener();
        setClickListener2();
    }
     Button button;
     Button button4;
    private void setClickListener() {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Register.this,Customer.class);
                startActivity(intent);
            }
        });
    }
    private void setClickListener2() {
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Register.this,Owner_Agent.class);
                startActivity(intent);
            }
        });
    }

    private void init() {
        button=findViewById(R.id.button);
        button4=findViewById(R.id.button4);


    }
}
