package com.example.homecoming;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.auth.api.signin.GoogleSignInApi;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;

public class LoginScreen extends AppCompatActivity implements View.OnClickListener, GoogleApiClient.OnConnectionFailedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);
        init();
        setClickListener();
    }
     TextView textView2;
   private void setClickListener() {
       textView2.setOnClickListener(new View.OnClickListener() {
       @Override
           public void onClick(View view) {
           Intent intent=new Intent(LoginScreen.this,Register.class);
           startActivity(intent);
       }
       });
   }
    private void init() {
        textView2=findViewById(R.id.textView2);

    }


    @Override
    public void onClick(View v) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

}
