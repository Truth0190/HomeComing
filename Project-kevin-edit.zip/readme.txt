-Made layouts look nicer (compare them if they seem weird for your emulator/device)
-Cleaned up code
-Removed logout button for Customer and Agent_Owner layouts as it didn't make sense for people to be logged in while also registering for an account they already have (just copy/paste the one in the layouts with graphs in it if you REALLY need it there)
	-Thinking about doing the same with the Login page but didn't yet
-Added some comments for stuff to do later

P.S. Submit button seems to not function as "intended for testing".