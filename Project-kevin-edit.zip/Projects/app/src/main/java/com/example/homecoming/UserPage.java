package com.example.homecoming;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class UserPage extends AppCompatActivity {

    private ListView list;
    private ArrayList<String> listItems;
    private MyAdapter adapter;
    private EditText filter;
    private Button btnLogout;
    private String titles[] = {"Dwell ATL", "One12 Courtland Apartments", "City Plaza", "Sylvan-Factory Partners", "Brooks Crossing Apartment"};
    private String description[] = {"171 Auburn Avenue NE, Atlanta, GA 30303", "112 Courtland St NE, Atlanta, GA 30303", "133 Trinity Ave SW, Atlanta, GA 30303", "233 Mitchell St SW # 345, Atlanta, GA 30303", "245 Peachtree Center Ave NE #400, Atlanta, GA 30303"};
    private int imgs[]={R.drawable.list1,R.drawable.list1,R.drawable.list1,R.drawable.list1, R.drawable.list1};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_page);
        init();
        initList();
    }

    private void init() {
        list = findViewById(R.id.listView);
        filter = findViewById(R.id.txtSearch);
        btnLogout = findViewById(R.id.btnLogout);
        MyAdapter adapter = new MyAdapter(this, titles, imgs, description);
        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(UserPage.this, "Item "+(position+1)+" clicked", Toast.LENGTH_SHORT).show();
            }
        });
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logout();
            }
        });
        filter.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //Does nothing
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                initList();
                if(!(s.toString().equals(""))){
                    searchItem(s.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                //Does nothing
            }

        });
    }

    //TODO do stuff with google and maybe security stuff as well
    public void logout() {
        finish();
    }

    //TODO currently does not work, fix at some point
    public void searchItem(String textToSearch){

        for(String item: description){
            if(!(item.contains(textToSearch))){
                listItems.remove(item);
            }
        }

        adapter.notifyDataSetChanged();
    }

    //TODO this might need some work as well
    public void initList(){
        //titles = new String[]{"Dwell ATL", "One12 Courtland Apartments", "City Plaza", "Sylvan-Factory Partners", "Brooks Crossing Apartment"};
        description = new String[]{"171 Auburn Avenue NE, Atlanta, GA 30303", "112 Courtland St NE, Atlanta, GA 30303", "133 Trinity Ave SW, Atlanta, GA 30303", "233 Mitchell St SW # 345, Atlanta, GA 30303", "245 Peachtree Center Ave NE #400, Atlanta, GA 30303"};
        listItems = new ArrayList<>(Arrays.asList(description));
        adapter = new MyAdapter(this, titles, imgs, description);
        list.setAdapter(adapter);
    }

    @Override
    public void onBackPressed() {
        //Overridden to do nothing to prevent people from logging off via back button
    }

    class MyAdapter extends ArrayAdapter<String> {

        Context context;
        String myTitles[];
        String myDescription[];
        int[] imgs;

        MyAdapter(Context c, String[] titles, int[] imgs, String[] description) {
            super(c,R.layout.house_row, R.id.txtAddress, description);
            this.context=c;
            this.imgs=imgs;
            this.myTitles=titles;
            this.myDescription=description;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater)   getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = layoutInflater.inflate(R.layout.house_row, parent, false);
            ImageView images = (ImageView) row.findViewById(R.id.logo);
            TextView myTitle = (TextView) row.findViewById(R.id.txtName);
            TextView myDescription = (TextView) row.findViewById(R.id.txtAddress);
            images.setImageResource(imgs[position]);
            myTitle.setText(titles[position]);
            myDescription.setText(description[position]);
            return row;
        }
    }

}
