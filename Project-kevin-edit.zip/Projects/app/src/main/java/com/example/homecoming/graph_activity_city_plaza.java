package com.example.homecoming;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class graph_activity_city_plaza extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph_city_plaza);
    }
}
