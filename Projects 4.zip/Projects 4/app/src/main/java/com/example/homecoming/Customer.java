 package com.example.homecoming;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.spark.submitbutton.SubmitButton;

 public class Customer extends AppCompatActivity {

    private SubmitButton btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer);
        init();
        setClickListener();
    }

     private void init() {
         btnSubmit = findViewById(R.id.btnSubmit);
     }

     /*
         TODO add registration verification
         -If: connection to database error, notify "can't connect to homecoming server"
         -Else If: something filled out is wrong, say something like "the following went wrong:" plus a list of what went wrong.
         -Else: register new user into database and go back to login screen(?)
     */
     private void setClickListener() {
         btnSubmit.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 Intent intent = new Intent(Customer.this, UserPage.class);
                 startActivity(intent);
                 //TODO if registration is successful, do this.
                 finish();
             }
         });
     }
}
