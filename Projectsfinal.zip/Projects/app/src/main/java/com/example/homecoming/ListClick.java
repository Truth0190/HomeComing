package com.example.homecoming;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ListClick extends AppCompatActivity {

    ListView list;
    String titles[] = {"Dwell ATL", "One12 Courtland Apartments", "City Plaza", "Sylvan-Factory Partners", "Brooks Crossing Apartment"};
    String description[] = {"171 Auburn Avenue NE, Atlanta, GA 30303", "112 Courtland St NE, Atlanta, GA 30303", "133 Trinity Ave SW, Atlanta, GA 30303", "233 Mitchell St SW # 345, Atlanta, GA 30303", "245 Peachtree Center Ave NE #400, Atlanta, GA 30303"};
    int imgs[]={R.drawable.list1,R.drawable.list1,R.drawable.list1,R.drawable.list1, R.drawable.list1};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_click);


        list = (ListView) findViewById(R.id.cus_list_view);

        MyAdapter adapter = new MyAdapter(this,titles,imgs,description);
        list.setAdapter(adapter);

        //click to go to another activity
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Toast.makeText(ListClick.this, "Item 1 clicked", Toast.LENGTH_SHORT).show();
                    Intent myintent1 = new Intent(view.getContext(), Graph_Dewll_ATL.class);
                    startActivityForResult(myintent1,0);
                }
                else if (position == 1) {
                    Toast.makeText(ListClick.this, "Item 2 clicked", Toast.LENGTH_SHORT).show();
                }
                else if (position == 2) {
                    Toast.makeText(ListClick.this, "Item 3 clicked", Toast.LENGTH_SHORT).show();
                    Intent myintent = new Intent(view.getContext(), graph_city_plaza.class);
                    startActivityForResult(myintent,2);
                }
                else if (position == 3) {
                    Toast.makeText(ListClick.this, "Item 4 clicked", Toast.LENGTH_SHORT).show();
                }
                else if (position == 4) {
                    Toast.makeText(ListClick.this, "Item 5 clicked", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }


    class MyAdapter extends ArrayAdapter<String> {

        Context context;
        String myTitles[];
        String myDescription[];
        int[] imgs;

        MyAdapter(Context c, String[] titles, int[] imgs, String[] description) {
            super(c,R.layout.row,R.id.text1,titles);
            this.context=c;
            this.imgs=imgs;
            this.myTitles=titles;
            this.myDescription=description;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent)
        {
            LayoutInflater layoutInflater = (LayoutInflater)   getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = layoutInflater.inflate(R.layout.row, parent, false);
            ImageView images = (ImageView) row.findViewById(R.id.logo);
            TextView myTitle = (TextView) row.findViewById(R.id.text1);
            TextView myDescription = (TextView) row.findViewById(R.id.text2);
            images.setImageResource(imgs[position]);
            myTitle.setText(titles[position]);
            myDescription.setText(description[position]);
            return row;
        }
    }
}